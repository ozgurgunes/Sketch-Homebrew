var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/zoom-tool.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/analytics.js":
/*!**************************!*\
  !*** ./src/analytics.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/settings */ "sketch/settings");
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_settings__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (function (label, value) {
  var analyticsAllowed = sketch_settings__WEBPACK_IMPORTED_MODULE_0___default.a.settingForKey('analyticsAllowed') || false;

  if (analyticsAllowed != true) {
    var dialog = NSAlert.alloc().init();

    if (context.plugin.alertIcon()) {
      dialog.icon = context.plugin.alertIcon();
    }

    dialog.setMessageText('Allow Google Analytics');
    dialog.setInformativeText('Please allow ' + context.plugin.name() + ' ' + 'plugin to use Google Analytics for tracking statistics.');
    dialog.addButtonWithTitle('Allow');
    dialog.addButtonWithTitle('Disallow');
    var response = dialog.runModal();

    if (response == 1000) {
      analyticsAllowed = true;
      sketch_settings__WEBPACK_IMPORTED_MODULE_0___default.a.setSettingForKey('analyticsAllowed', analyticsAllowed);
    }
  }

  if (analyticsAllowed) {
    return analytics(label, value);
  }
});

var analytics = function analytics(label, value) {
  var kUUIDKey = 'google.analytics.uuid';
  var uuid = NSUserDefaults.standardUserDefaults().objectForKey(kUUIDKey);

  if (!uuid) {
    uuid = NSUUID.UUID().UUIDString();
    NSUserDefaults.standardUserDefaults().setObject_forKey(uuid, kUUIDKey);
    NSUserDefaults.standardUserDefaults().synchronize();
  }

  var payload = {
    v: 1,
    tid: 'UA-5738625-2',
    ds: 'Sketch ' + MSApplicationMetadata.metadata().appVersion,
    cid: uuid,
    t: 'event',
    an: context.plugin.name(),
    aid: context.plugin.identifier(),
    av: context.plugin.version(),
    ec: context.plugin.name(),
    ea: context.command.name()
  };

  if (label) {
    payload.el = label;
  }

  if (value) {
    payload.ev = value;
  }

  var url = NSURL.URLWithString(NSString.stringWithFormat('https://www.google-analytics.com/collect%@', jsonToQueryString(payload)));

  if (url) {
    NSURLSession.sharedSession().dataTaskWithURL(url).resume();
  }
};

var jsonToQueryString = function jsonToQueryString(json) {
  return '?' + Object.keys(json).map(function (key) {
    return encodeURIComponent(key) + '=' + encodeURIComponent(json[key]);
  }).join('&');
};

/***/ }),

/***/ "./src/zoom-tool.js":
/*!**************************!*\
  !*** ./src/zoom-tool.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _analytics_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./analytics.js */ "./src/analytics.js");



var doc = sketch_dom__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();
var zoomValue = Math.round(100 * doc.sketchObject.zoomValue()) / 100;
/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.getInputFromUser('Zoom (%):', {
    initialValue: zoomValue * 100
  }, function (err, value) {
    if (err) {// most likely the user canceled the input
    } else if (!Number.isInteger(Number(value))) {
      // accept integer only
      var message = 'Please enter numbers only.';
      Object(_analytics_js__WEBPACK_IMPORTED_MODULE_2__["default"])('Fail');
      sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.message('Zoom: ' + message);
    } else {
      setZoom(value);
      Object(_analytics_js__WEBPACK_IMPORTED_MODULE_2__["default"])('Done', 1);
      sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.message('Zoom: ' + value + '%');
    }
  });
});

var setZoom = function setZoom(zoom) {
  var ratio = zoomValue / Number(zoom) * 100;
  var viewRect = doc.sketchObject.contentDrawView().visibleContentRect();
  var targetRect = viewRect;
  var centerX = viewRect.origin.x + viewRect.size.width / 2;
  var centerY = viewRect.origin.y + viewRect.size.height / 2;
  targetRect.size.width = viewRect.size.width * ratio;
  targetRect.size.height = viewRect.size.height * ratio;
  targetRect.origin.x = centerX - targetRect.size.width / 2;
  targetRect.origin.y = centerY - targetRect.size.height / 2;
  viewRect = targetRect;

  if (zoom) {
    doc.sketchObject.contentDrawView().zoomToFitRect(targetRect);
  }
};

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=zoom-tool.js.map
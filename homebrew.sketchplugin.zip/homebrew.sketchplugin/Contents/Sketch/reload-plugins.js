var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/reload-plugins.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/analytics.js":
/*!**************************!*\
  !*** ./src/analytics.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/settings */ "sketch/settings");
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_settings__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (function (label, value) {
  var analyticsAllowed = sketch_settings__WEBPACK_IMPORTED_MODULE_0___default.a.settingForKey('analyticsAllowed') || false;

  if (analyticsAllowed != true) {
    var dialog = NSAlert.alloc().init();

    if (context.plugin.alertIcon()) {
      dialog.icon = context.plugin.alertIcon();
    }

    dialog.setMessageText('Allow Google Analytics');
    dialog.setInformativeText('Please allow ' + context.plugin.name() + ' ' + 'plugin to use Google Analytics for tracking statistics.');
    dialog.addButtonWithTitle('Allow');
    dialog.addButtonWithTitle('Disallow');
    var response = dialog.runModal();

    if (response == 1000) {
      analyticsAllowed = true;
      sketch_settings__WEBPACK_IMPORTED_MODULE_0___default.a.setSettingForKey('analyticsAllowed', analyticsAllowed);
    }
  }

  if (analyticsAllowed) {
    return analytics(label, value);
  }
});

var analytics = function analytics(label, value) {
  var kUUIDKey = 'google.analytics.uuid';
  var uuid = NSUserDefaults.standardUserDefaults().objectForKey(kUUIDKey);

  if (!uuid) {
    uuid = NSUUID.UUID().UUIDString();
    NSUserDefaults.standardUserDefaults().setObject_forKey(uuid, kUUIDKey);
    NSUserDefaults.standardUserDefaults().synchronize();
  }

  var payload = {
    v: 1,
    tid: 'UA-5738625-2',
    ds: 'Sketch ' + MSApplicationMetadata.metadata().appVersion,
    cid: uuid,
    t: 'event',
    an: context.plugin.name(),
    aid: context.plugin.identifier(),
    av: context.plugin.version(),
    ec: context.plugin.name(),
    ea: context.command.name()
  };

  if (label) {
    payload.el = label;
  }

  if (value) {
    payload.ev = value;
  }

  var url = NSURL.URLWithString(NSString.stringWithFormat('https://www.google-analytics.com/collect%@', jsonToQueryString(payload)));

  if (url) {
    NSURLSession.sharedSession().dataTaskWithURL(url).resume();
  }
};

var jsonToQueryString = function jsonToQueryString(json) {
  return '?' + Object.keys(json).map(function (key) {
    return encodeURIComponent(key) + '=' + encodeURIComponent(json[key]);
  }).join('&');
};

/***/ }),

/***/ "./src/reload-plugins.js":
/*!*******************************!*\
  !*** ./src/reload-plugins.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _analytics_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./analytics.js */ "./src/analytics.js");
/* harmony import */ var _ui_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ui.js */ "./src/ui.js");


/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  try {
    var paneController = MSPreferencesController.sharedController();
    var pane = paneController.currentPreferencePane();

    if (!pane) {
      pane = MSPluginsPreferencePane.alloc().initWithPreferencesController(paneController);
    }

    pane.pluginManager().reloadPlugins();
    Object(_analytics_js__WEBPACK_IMPORTED_MODULE_0__["default"])('Done', 1);
    _ui_js__WEBPACK_IMPORTED_MODULE_1__["success"]('Plugins reloaded.');
  } catch (e) {
    console.log(e);
    Object(_analytics_js__WEBPACK_IMPORTED_MODULE_0__["default"])('Fail');
    return _ui_js__WEBPACK_IMPORTED_MODULE_1__["error"]('Something went wrong!');
  }
});

/***/ }),

/***/ "./src/ui.js":
/*!*******************!*\
  !*** ./src/ui.js ***!
  \*******************/
/*! exports provided: message, error, success, dialog, textField, comboBox, popUpButton, slider, scrollView, optionList, errorList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "message", function() { return message; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "error", function() { return error; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "success", function() { return success; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dialog", function() { return dialog; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "textField", function() { return textField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "comboBox", function() { return comboBox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "popUpButton", function() { return popUpButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "slider", function() { return slider; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "scrollView", function() { return scrollView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "optionList", function() { return optionList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "errorList", function() { return errorList; });
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_0__);

var message = function message(msg, status) {
  var emoji = '';

  switch (status) {
    case 'error':
      emoji = '⚠️   ';
      break;

    case 'success':
      emoji = '✅   ';
      break;
  }

  sketch_ui__WEBPACK_IMPORTED_MODULE_0___default.a.message(emoji + context.command.name() + ': ' + msg);
};
var error = function error(msg) {
  return message(msg, 'error');
};
var success = function success(msg) {
  return message(msg, 'success');
};
var dialog = function dialog(info, accessory, buttons, message) {
  buttons = buttons || ['OK'];
  message = message || context.command.name();
  var alert = NSAlert.alloc().init();
  alert.setMessageText(message);
  alert.setInformativeText(info);
  buttons.map(function (button) {
    return alert.addButtonWithTitle(button);
  });

  if (context.plugin.alertIcon()) {
    alert.icon = context.plugin.alertIcon();
  }

  if (accessory) {
    alert.setAccessoryView(accessory);

    if (!accessory.isMemberOfClass(NSTextView)) {
      alert.window().setInitialFirstResponder(accessory);
    }
  }

  return alert.runModal();
};
var textField = function textField(initial) {
  var accessory = NSTextField.alloc().initWithFrame(NSMakeRect(0, 0, 240, 25));
  accessory.setStringValue(initial || '');
  return accessory;
};
var comboBox = function comboBox(items) {
  var accessory = NSComboBox.alloc().initWithFrame(NSMakeRect(0, 0, 240, 25));
  accessory.addItemsWithObjectValues(items);
  accessory.setEditable(true);
  accessory.setCompletes(true);
  return accessory;
};
var popUpButton = function popUpButton(items) {
  var accessory = NSPopUpButton.alloc().initWithFrame(NSMakeRect(0, 0, 240, 25));
  accessory.addItemsWithTitles(items);
  return accessory;
};
var slider = function slider(options) {
  var accessory = NSSlider.alloc().initWithFrame(NSMakeRect(0, 0, 240, 25));
  accessory.setFloatValue(Number(options.initialValue || 0));
  accessory.setMinValue(options.minValue || 1);
  accessory.setMaxValue(options.maxValue || 10);
  accessory.setAllowsTickMarkValuesOnly(true);
  accessory.setNumberOfTickMarks(parseInt(1 + ((typeof options.maxValue !== 'undefined' ? options.maxValue : 1) - (typeof options.minValue !== 'undefined' ? options.minValue : 0)) / options.increment, 10));
  return accessory;
};
var scrollView = function scrollView(view) {
  var accessory = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 300, 120));
  var scrollView = NSScrollView.alloc().initWithFrame(NSMakeRect(0, 0, 300, 120));
  scrollView.setHasVerticalScroller(true);
  scrollView.setHasHorizontalScroller(false);
  scrollView.setDocumentView(view);
  accessory.addSubview(scrollView);
  return accessory;
};
var optionList = function optionList(items) {
  var listView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 300, items.length * 24 + 10));
  var options = [];
  items.map(function (item, i) {
    options[i] = NSButton.alloc().initWithFrame(NSMakeRect(5, 5 + i * 24, 290, 20));
    options[i].setButtonType(NSSwitchButton);
    options[i].setTitle(item);
    options[i].setState(false);
    listView.addSubview(options[i]);
    listView.setFlipped(true);
  });
  return {
    options: options,
    view: listView,
    getSelection: function getSelection() {
      var selection = [];
      options.map(function (option, i) {
        if (option.state()) {
          selection.push(i);
        }
      });
      return selection;
    }
  };
};
var errorList = function errorList(items) {
  var listView = NSView.alloc().initWithFrame(NSMakeRect(0, 0, 300, items.length * 24 + 10));
  var font = NSFont.systemFontOfSize(NSFont.smallSystemFontSize());
  var errors = [];
  items.map(function (item, i) {
    errors[i] = NSTextView.alloc().initWithFrame(NSMakeRect(5, 10 + i * 24, 290, 20));
    errors[i].insertText(item);
    errors[i].setFont(font);
    errors[i].setEditable(false);
    listView.addSubview(errors[i]);
  });
  listView.setFlipped(true);
  return listView;
};

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=reload-plugins.js.map